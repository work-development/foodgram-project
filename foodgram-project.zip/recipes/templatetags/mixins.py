# class RecipeObjectMixin(object):
#
#     def get_context_data(self, **kwargs):
#         # Call class's get_context_data method to retrieve context
#         context = super().get_context_data(**kwargs)
#
#         context['page_title'] = 'My page title'
#         return context