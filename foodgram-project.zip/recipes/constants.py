ITEMS_PER_PAGE = 6
TAGS_LIST = ["breakfast", "lunch", "dinner"]
